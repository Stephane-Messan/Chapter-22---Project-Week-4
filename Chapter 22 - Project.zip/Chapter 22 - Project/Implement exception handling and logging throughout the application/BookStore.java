import java.util.logging.Level;
import java.util.logging.Logger;

public class BookStore {
    private static final Logger logger = Logger.getAnonymousLogger();

    public static void main(String[] args) {
        try {
            // Your book store logic here
            throw new RuntimeException("Something went wrong!");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Exception occurred", e);
        }
    }
}
