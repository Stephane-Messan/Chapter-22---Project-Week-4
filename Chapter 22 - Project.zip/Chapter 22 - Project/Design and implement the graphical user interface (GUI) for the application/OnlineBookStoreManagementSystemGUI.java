import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class OnlineBookStoreManagementSystemGUI extends JFrame {
private JPanel mainPanel;
private JMenuBar menuBar;
private JMenu fileMenu;
private JMenuItem exitMenuItem;
private JMenu bookMenu;
private JMenuItem addBookMenuItem;
private JMenuItem editBookMenuItem;
private JMenuItem deleteBookMenuItem;
private JMenu customerMenu;
private JMenuItem addCustomerMenuItem;
private JMenuItem editCustomerMenuItem;
private JMenuItem deleteCustomerMenuItem;
private JMenu orderMenu;
private JMenuItem placeOrderMenuItem;
private JMenuItem viewOrderMenuItem;
private JMenu helpMenu;
private JMenuItem aboutMenuItem;

public OnlineBookStoreManagementSystemGUI() {
super("Online Book Store Management System");
mainPanel = new JPanel();
mainPanel.setLayout(new BorderLayout());
menuBar = new JMenuBar();
fileMenu = new JMenu("File");
exitMenuItem = new JMenuItem("Exit");

exitMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
System.exit(0);
}
});
fileMenu.add(exitMenuItem);
bookMenu = new JMenu("Book");
addBookMenuItem = new JMenuItem("Add Book");
addBookMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// Add book code goes here
}
});
bookMenu.add(addBookMenuItem);
editBookMenuItem = new JMenuItem("Edit Book");
editBookMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// Edit book code goes here
}
});
bookMenu.add(editBookMenuItem);
deleteBookMenuItem = new JMenuItem("Delete Book");
deleteBookMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// Delete book code goes here
}
});
bookMenu.add(deleteBookMenuItem);
customerMenu = new JMenu("Customer");
addCustomerMenuItem = new JMenuItem("Add Customer");
addCustomerMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// Add customer code goes here
}
});
customerMenu.add(addCustomerMenuItem);
editCustomerMenuItem = new JMenuItem("Edit Customer");
editCustomerMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// Edit customer code goes here
}
});
customerMenu.add(editCustomerMenuItem);
deleteCustomerMenuItem = new JMenuItem("Delete Customer");
deleteCustomerMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// Delete customer code goes here
}
});
customerMenu.add(deleteCustomerMenuItem);
orderMenu = new JMenu("Order");
placeOrderMenuItem = new JMenuItem("Place Order");
placeOrderMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// Place order code goes here
}
});
orderMenu.add(placeOrderMenuItem);
viewOrderMenuItem = new JMenuItem("View Order");
viewOrderMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// View order code goes here
}
});
orderMenu.add(viewOrderMenuItem);
helpMenu = new JMenu("Help");
aboutMenuItem = new JMenuItem("About");
aboutMenuItem.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
// About code goes here
}
});
helpMenu.add(aboutMenuItem);
menuBar.add(fileMenu);
menuBar.add(bookMenu);
menuBar.add(customerMenu);
menuBar.add(orderMenu);
menuBar.add(helpMenu);
setJMenuBar(menuBar);
setContentPane(mainPanel);
setSize(800, 600);
setVisible(true);
}
public static void main(String[] args) {
new OnlineBookStoreManagementSystemGUI();
}
}
                        
                        
                        